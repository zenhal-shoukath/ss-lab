#include<stdio.h>
void main()
{
printf("program6a");
}
//single
/*multi*/
